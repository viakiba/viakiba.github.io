<?php 
function ocdi_import_files() {
  return array(
    array(
      'import_file_name'           => '魔术家园WordPress企业主题演示数据',
      'import_file_url'            => 'http://data.themepark.com.cn/2015/homemagic/homemagic-data.xml',
      'import_widget_file_url'     => 'http://data.themepark.com.cn/2015/homemagic/homemagic-data.wie',
      'import_customizer_file_url' => 'http://data.themepark.com.cn/2015/homemagic/homemagic-data.dat',
    
      'import_preview_image_url'   => 'http://data.themepark.com.cn/2018/cloudcommerce/homemagic-data.jpg',
      'import_notice'              => __( '魔术家园WordPress企业主题演示数据导入.', 'http://demo.themepark.com.cn/homemagic/' ),
      'preview_url'                => 'http://demo.themepark.com.cn/homemagic/',
    ),

  );
}
add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );


function no_nav_id($nav_name){
	
	$menus = wp_get_nav_menus( array( 'orderby' => 'name' ) );
	
	foreach ( $menus as $menu ) {
		if($nav_name=== $menu->name){
			
			$nav_id=$menu->term_id ;
		}
		
	}
	return $nav_id;	
}


function upload_nav_id(){	

	$locations = get_theme_mod( 'nav_menu_locations' );
    $locations['header-menu'] = no_nav_id("导航菜单");
	$locations['link-menu2'] = no_nav_id("友情链接");
	$locations['footer-menu'] = no_nav_id("底部菜单");
		$locations['tag-menu2'] = no_nav_id("多重筛选");
	set_theme_mod ( 'nav_menu_locations', $locations );
	
}








add_filter('use_block_editor_for_post', '__return_false');
remove_action( 'wp_enqueue_scripts', 'wp_common_block_scripts_and_styles' );

