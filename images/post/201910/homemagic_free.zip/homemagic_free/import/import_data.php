<?php
function import_data_function(){
	
	if($_POST['Submit']) {

		
		
	}
	
	?>
<style>
	.welcom h1{font-size: 36px;}
	.welcom p{font-size: 18px;}
</style>


<div class="welcom">
	
	<h1>欢迎使用WEB主题公园</h1>
	<p>如果你是新装网站，那么现在查看网站首页空空如也，想要从零开始搭建可是一件很累人的事情！</p>
	<p>不用担心，我们提供了导入数据，点击下面的按钮跳转到导入数据插件下载地址，去下载插件并安装，</p>
	<p>即可在WordPress后台--外观处找到导入数据的入口，查看演示并选择你想要导入的数据，轻轻点击即可将数据导入到你的网站</p>
	<p>导入之后，你将获得一个完整的网站，而无需从零开始搭建了。</p>
	<p>如果是原有网站更换主题，导入数据也是可以的，只不过会将你的网站增加很多内容，不过删除他们也是非常简单的。</p>
	<a target="_blank" href="https://www.themepark.com.cn/wordpressyjdrsjcjxz.html">前往下载导入数据插件</a>
	
</div>


<?php } ?>